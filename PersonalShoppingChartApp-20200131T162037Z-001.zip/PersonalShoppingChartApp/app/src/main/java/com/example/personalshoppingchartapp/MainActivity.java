package com.example.personalshoppingchartapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Tran1(View view)
    {
        Intent intent = new Intent(MainActivity.this, Hardware.class);
        startActivity(intent);
    }

    public void tran2(View view)
    {

    }

    public void tran3(View view)
    {

    }

    public void tran4(View view)
    {

    }
}
